def get_version():
    version = '1.0.4'
    return version
