def get_version():
    version = '1.0.5'
    return version
